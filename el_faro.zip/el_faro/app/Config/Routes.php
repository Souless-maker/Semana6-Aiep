<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Ruta principal
$routes->get('/', 'Home::index');
$routes->get('seccion/(:segment)', 'Home::seccion/$1');
$routes->get('articulo/(:num)', 'Home::articulo/$1');
$routes->get('buscar', 'Home::buscar');

// Rutas de contacto
$routes->get('contacto', 'Contacto::index');
$routes->post('contacto/enviar', 'Contacto::enviar');

// Rutas de usuario
$routes->get('usuario/login', 'Usuario::login');
$routes->get('usuario/registro', 'Usuario::registro');
$routes->post('usuario/autenticar', 'Usuario::autenticar');
$routes->post('usuario/crearCuenta', 'Usuario::crearCuenta');
$routes->get('usuario/logout', 'Usuario::logout');
$routes->get('usuario/perfil', 'Usuario::perfil');

// Rutas de administración
$routes->get('admin', 'Admin::index');