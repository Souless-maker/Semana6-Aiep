<?php

namespace App\Models;

use CodeIgniter\Model;

class ArticuloModel extends Model
{
    protected $table = 'articulos';
    protected $primaryKey = 'id';
    protected $allowedFields = ['titulo', 'contenido', 'resumen', 'imagen', 'categoria_id', 'usuario_id', 'activo'];
    protected $useTimestamps = false;
    
    protected $validationRules = [
        'titulo' => 'required|min_length[5]|max_length[200]',
        'contenido' => 'required|min_length[10]',
        'resumen' => 'max_length[300]',
        'categoria_id' => 'required|integer'
    ];
    
    public function obtenerArticulosConCategoria($limite = null, $categoriaId = null)
    {
        $builder = $this->select('articulos.*, categorias.nombre as categoria_nombre, usuarios.nombre as autor_nombre')
                       ->join('categorias', 'categorias.id = articulos.categoria_id', 'left')
                       ->join('usuarios', 'usuarios.id = articulos.usuario_id', 'left')
                       ->where('articulos.activo', 1)
                       ->orderBy('articulos.fecha_publicacion', 'DESC');
        
        if ($categoriaId) {
            $builder->where('articulos.categoria_id', $categoriaId);
        }
        
        if ($limite) {
            $builder->limit($limite);
        }
        
        return $builder->get()->getResultArray();
    }
    
    public function obtenerArticuloCompleto($id)
    {
        return $this->select('articulos.*, categorias.nombre as categoria_nombre, usuarios.nombre as autor_nombre')
                   ->join('categorias', 'categorias.id = articulos.categoria_id', 'left')
                   ->join('usuarios', 'usuarios.id = articulos.usuario_id', 'left')
                   ->where('articulos.id', $id)
                   ->where('articulos.activo', 1)
                   ->first();
                   var_dump($result); exit; // <-- agrega esto
                   return $result;
    }
    
    public function obtenerArticulosRecientes($limite = 5)
    {
        return $this->obtenerArticulosConCategoria($limite);
    }
    
    public function buscarArticulos($termino)
    {
        return $this->select('articulos.*, categorias.nombre as categoria_nombre')
                   ->join('categorias', 'categorias.id = articulos.categoria_id', 'left')
                   ->where('articulos.activo', 1)
                   ->groupStart()
                       ->like('articulos.titulo', $termino)
                       ->orLike('articulos.contenido', $termino)
                       ->orLike('articulos.resumen', $termino)
                   ->groupEnd()
                   ->orderBy('articulos.fecha_publicacion', 'DESC')
                   ->get()->getResultArray();
    }
}